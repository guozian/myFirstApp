//
//  Post.swift
//  MyFirstApp
//
//  Created by Hui Guo on 16/8/21.
//  Copyright © 2016年 Leo. All rights reserved.
//

import Foundation
import UIKit

class Posts: NSObject {
    
    var postTitle:String = ""
    var postContent: String = ""
    var postThumbnailUrlString: String = ""
    var postCategoryName: String = ""
    var postDate: String = ""
    
    //Mark - Post Author
    
    var postAuthorDictionary = NSDictionary()
    var postAuthorArray = NSArray()
    var postAuthorListUrl: String = ""
    
}