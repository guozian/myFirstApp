//
//  ThirdCollectionViewCell.swift
//  MyFirstApp
//
//  Created by Hui Guo on 16/8/21.
//  Copyright © 2016年 Leo. All rights reserved.
//

import UIKit

class ThirdCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var postThumbnailImageView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var contentLabel: UILabel!
}
