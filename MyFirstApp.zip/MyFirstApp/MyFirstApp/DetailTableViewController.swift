//
//  DetailTableViewController.swift
//  MyFirstApp
//
//  Created by Hui Guo on 16/8/21.
//  Copyright © 2016年 Leo. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage

class DetailTableViewController: UITableViewController {

    var passPost: Posts = Posts()
    var author: Author = Author()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getAuthor()
        
        self.tableView.estimatedRowHeight = 70
        self.tableView.rowHeight = UITableViewAutomaticDimension
        
    }
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 2
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if indexPath.section == 0{
            let cell = tableView.dequeueReusableCellWithIdentifier("detailCell")
            
            //Mark - Set Cover Image
            
            let postImageUrlString = passPost.postThumbnailUrlString
            let postImageUrl = NSURL(string: postImageUrlString)
            let size = CGSize(width: 414.0, height:212.0 )
            let filter = AspectScaledToFillSizeFilter(size: size)
            (cell?.contentView.viewWithTag(1) as! UIImageView).af_setImageWithURL(postImageUrl!, filter: filter)
            
            //Set Author Avatar
            
            let authorAvatarUrlString = author.authorAvatarUrlString
            let authorAvatarUrl = NSURL(string: authorAvatarUrlString)
            
            //Mark - Give Author Avatar a Round Corner
            
            let filter2 = AspectScaledToFillSizeWithRoundedCornersFilter(size: (cell?.contentView.viewWithTag(2) as! UIImageView).frame.size, radius: 20.0)
            
            (cell?.contentView.viewWithTag(2) as! UIImageView).af_setImageWithURL(authorAvatarUrl!, filter: filter2)
            
            //Mark - Give BlurView A Round Corner
            
            let path = UIBezierPath(roundedRect:(cell?.contentView.viewWithTag(7) as! UIVisualEffectView).bounds, byRoundingCorners:[.BottomRight, .BottomLeft, .TopLeft, .TopRight], cornerRadii: CGSize(width: 20, height:  20))
            let maskLayer = CAShapeLayer()
            maskLayer.path = path.CGPath
            (cell?.contentView.viewWithTag(7) as! UIVisualEffectView).layer.mask = maskLayer
            (cell?.contentView.viewWithTag(7) as! UIVisualEffectView).layer.mask = maskLayer

            
            (cell?.contentView.viewWithTag(3) as! UILabel).text = author.authorName
            
            //Set Post Title and Content and so on
            
            (cell?.contentView.viewWithTag(4) as! UILabel).text = passPost.postTitle
            (cell?.contentView.viewWithTag(6) as! UILabel).text = passPost.postContent
            
            //Mark - Customize Date Formate
            
            let index = passPost.postDate.startIndex.advancedBy(10)
            (cell?.contentView.viewWithTag(5) as! UILabel).text = passPost.postDate.substringToIndex(index)
            
            return cell!
        }
        else{
            let cell = tableView.dequeueReusableCellWithIdentifier("commentCell")
            (cell?.contentView.viewWithTag(1) as! UILabel).text = passPost.postTitle
            
            return cell!
        }
        
    }
    
    //Mark - Get Author Information
    
    func getAuthor(){
        
        Alamofire.request(.GET, passPost.postAuthorListUrl).responseJSON { (response) in
            if let authorJsonFile = response.result.value{
                var arrayOfAuthor = [Author]()
                let authorObj = Author()
                
                authorObj.authorAvatarUrlDic = authorJsonFile.valueForKeyPath("avatar_urls") as! NSDictionary
                authorObj.authorAvatarUrlString = (authorObj.authorAvatarUrlDic).valueForKeyPath("96") as! String
                authorObj.authorDescription = authorJsonFile.valueForKeyPath("description") as! String
                authorObj.authorName = authorJsonFile.valueForKeyPath("name") as! String
                arrayOfAuthor.append(authorObj)
                self.author = authorObj
                self.tableView.reloadData()
            }
        }
    }
    
    
}
