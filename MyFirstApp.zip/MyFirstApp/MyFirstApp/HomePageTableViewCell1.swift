//
//  HomePageTableViewCell1.swift
//  MyFirstApp
//
//  Created by Hui Guo on 16/8/21.
//  Copyright © 2016年 Leo. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage

protocol PostDelegate {
    func selectedPost(post: Posts, index: Int)
}

class HomePageTableViewCell1: UITableViewCell, UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet weak var firstCategoryCollectionView: UICollectionView!
    
    var categories: [Category] = [Category]()
    var post1: [Posts] = [Posts]()
    var post2: [Posts] = [Posts]()
    var author: [Author] = [Author]()
    
    var postDelegate: PostDelegate?

    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return min(4, post1.count)
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("CollectionViewCell1", forIndexPath: indexPath) as! FirstCollectionViewCell
        
        //Mark - Parse Thumbnail Image To the Customized CollectionViewCell
        
        let thumbnailUrlString: String = post1[indexPath.row].postThumbnailUrlString
        let thumbnailUrl = NSURL(string: thumbnailUrlString)
        
        //Mark - Give ImageView A Round Corner
        
        let filter = AspectScaledToFillSizeWithRoundedCornersFilter(size: cell.postImageView.frame.size, radius: 20.0)
        
        cell.postImageView.af_setImageWithURL(thumbnailUrl!, filter: filter)
        cell.postTitleLabel.text = post1[indexPath.row].postTitle
        
        //Mark - Give BlurView A Round Corner
        
        let path = UIBezierPath(roundedRect:cell.bounds, byRoundingCorners:[.BottomRight, .BottomLeft, .TopRight, .TopLeft], cornerRadii: CGSize(width: 20, height:  20))
        let maskLayer = CAShapeLayer()
        maskLayer.path = path.CGPath
        cell.layer.mask = maskLayer
        cell.layer.mask = maskLayer

        return cell
    }
    
    //Mark - Let CollectionViewCell Scroll Automatically
    
    func scrollToNextCell(){
        
        //get cell size
        
        let cellSize = CGSizeMake(self.firstCategoryCollectionView.frame.width, self.firstCategoryCollectionView.frame.height);
        
        //get current content Offset of the Collection view
        let contentOffset = firstCategoryCollectionView.contentOffset;
        
        if firstCategoryCollectionView.contentSize.width <= firstCategoryCollectionView.contentOffset.x + cellSize.width
        {
            firstCategoryCollectionView.scrollRectToVisible(CGRectMake(0, contentOffset.y, cellSize.width, cellSize.height), animated: true);
            
            
        } else {
            firstCategoryCollectionView.scrollRectToVisible(CGRectMake(contentOffset.x + cellSize.width - 2.5, contentOffset.y, cellSize.width - 2.5, cellSize.height), animated: true);
            
        }
        
    }
    
    /**
     Invokes Timer to start Automatic Animation with repeat enabled
     */
    func startTimer() {
        NSTimer.scheduledTimerWithTimeInterval(3.0, target: self, selector: #selector(HomePageTableViewCell1.scrollToNextCell), userInfo: nil, repeats: true);
        
    }
    
    //Mark - Download Data From JSON
    
    func getCategory() {
        
        Alamofire.request(.GET, "http://localhost:8888/wordpress/wp-json/wp/v2/categories").responseJSON { (response) in
            if let jsonFile = response.result.value{
                var arrayOfCategory = [Category]()
                for category in jsonFile as! NSArray {
                    let categoryObj = Category()
                    
                    categoryObj.postCategoryName = category.valueForKeyPath("name") as! String
                    categoryObj.postCategoryCode = category.valueForKeyPath("id") as! NSNumber
                    categoryObj.theDictionary = category.valueForKeyPath("_links") as! NSDictionary
                    categoryObj.theCategoryArray = (categoryObj.theDictionary).valueForKeyPath("wp:post_type") as! NSArray
                    categoryObj.postCategoryListUrl = categoryObj.theCategoryArray[0].valueForKeyPath("href") as! String
                    
                    arrayOfCategory.append(categoryObj)
                }
                
                self.categories = arrayOfCategory
                
                //Mark - Download Post Data Based on Category
                
                for categoryItem in self.categories {
                    
                    let categoryCode = categoryItem.postCategoryCode
                    let categoryListUrlString = categoryItem.postCategoryListUrl
                    
                    Alamofire.request(.GET, categoryListUrlString).responseJSON(completionHandler: { (response) in
                        if let postJsonFile = response.result.value{
                            var arrayOfPost = [Posts]()
                            
                            for post in postJsonFile as! NSArray {
                                
                                let postObj = Posts()
                                
                                postObj.postTitle = post.valueForKeyPath("title.rendered") as! String
                                postObj.postDate = post.valueForKeyPath("date") as! String
                                postObj.postCategoryName = categoryItem.postCategoryName
                                postObj.postContent = post.valueForKeyPath("content.rendered") as! String
                                postObj.postThumbnailUrlString = post.valueForKeyPath("featured_image_thumbnail_url") as! String
                                postObj.postAuthorDictionary = post.valueForKeyPath("_links") as! NSDictionary
                                postObj.postAuthorArray = (postObj.postAuthorDictionary).valueForKeyPath("author") as! NSArray
                                postObj.postAuthorListUrl = (postObj.postAuthorArray)[0].valueForKeyPath("href") as! String
                                
                                arrayOfPost.append(postObj)
                            }
                            
                            //Mark - Classify Posts Based on Category Type
                            
                            if categoryCode == 1 {
                                self.post1 = arrayOfPost
                                self.firstCategoryCollectionView.reloadData()
                                
                            }
                            if categoryCode == 2 {
                                self.post2 = arrayOfPost
                                self.firstCategoryCollectionView.reloadData()
                            }
                            
                        }
                    })
                }
            }
        }
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        postDelegate?.selectedPost(self.post1[indexPath.row], index: 0)
    }
}


extension HomePageTableViewCell1: UIScrollViewDelegate{
    
    func scrollViewWillEndDragging(scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        let layout = self.firstCategoryCollectionView.collectionViewLayout as! UICollectionViewFlowLayout
        let cellWidthIncludingSpacing = layout.itemSize.width + layout.minimumLineSpacing
        
        var offSet = targetContentOffset.memory
        let index = (offSet.x + scrollView.contentInset.left) / cellWidthIncludingSpacing
        let roundedIndex = round(index)
        
        offSet = CGPoint(x: roundedIndex * cellWidthIncludingSpacing - scrollView.contentInset.left, y: -scrollView.contentInset.top)
        targetContentOffset.memory = offSet
    }
}






















