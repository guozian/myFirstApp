//
//  HomePageTableViewCell3.swift
//  MyFirstApp
//
//  Created by Hui Guo on 16/8/21.
//  Copyright © 2016年 Leo. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage

class HomePageTableViewCell3: UITableViewCell, UICollectionViewDataSource, UICollectionViewDelegate {

    @IBOutlet weak var thirdCategoryCollectionView: UICollectionView!
    
    var categories: [Category] = [Category]()
    var post1: [Posts] = [Posts]()
    var post2: [Posts] = [Posts]()
    
    var postDelegate: PostDelegate?
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return min(4, post2.count)
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("CollectionViewCell3", forIndexPath: indexPath) as! ThirdCollectionViewCell
        
        //Mark - Parse Thumbnail Image To the Customized CollectionViewCell
        
        let thumbnailUrlString: String = post2[indexPath.row].postThumbnailUrlString
        let thumbnailUrl = NSURL(string: thumbnailUrlString)
        
        //Mark - Give ImageView A Round Corner
        
        let filter = AspectScaledToFillSizeWithRoundedCornersFilter(size: cell.postThumbnailImageView.frame.size, radius: 5.0)
        
        cell.postThumbnailImageView.af_setImageWithURL(thumbnailUrl!, filter: filter)
        cell.titleLabel.text = post2[indexPath.row].postTitle
        cell.contentLabel.text = post2[indexPath.row].postContent
        
        
        return cell
    }
    
    
    
    //Mark - Download Data From JSON
    
    func getCategory() {
        
        Alamofire.request(.GET, "http://localhost:8888/wordpress/wp-json/wp/v2/categories").responseJSON { (response) in
            if let jsonFile = response.result.value{
                var arrayOfCategory = [Category]()
                for category in jsonFile as! NSArray {
                    let categoryObj = Category()
                    
                    categoryObj.postCategoryName = category.valueForKeyPath("name") as! String
                    categoryObj.postCategoryCode = category.valueForKeyPath("id") as! NSNumber
                    categoryObj.theDictionary = category.valueForKeyPath("_links") as! NSDictionary
                    categoryObj.theCategoryArray = (categoryObj.theDictionary).valueForKeyPath("wp:post_type") as! NSArray
                    categoryObj.postCategoryListUrl = categoryObj.theCategoryArray[0].valueForKeyPath("href") as! String
                    
                    arrayOfCategory.append(categoryObj)
                }
                
                self.categories = arrayOfCategory
                
                //Mark - Download Post Data Based on Category
                
                for categoryItem in self.categories {
                    
                    let categoryCode = categoryItem.postCategoryCode
                    let categoryListUrlString = categoryItem.postCategoryListUrl
                    
                    Alamofire.request(.GET, categoryListUrlString).responseJSON(completionHandler: { (response) in
                        if let postJsonFile = response.result.value{
                            var arrayOfPost = [Posts]()
                            
                            for post in postJsonFile as! NSArray {
                                
                                let postObj = Posts()
                                
                                postObj.postTitle = post.valueForKeyPath("title.rendered") as! String
                                postObj.postDate = post.valueForKeyPath("date") as! String
                                postObj.postCategoryName = categoryItem.postCategoryName
                                postObj.postContent = post.valueForKeyPath("content.rendered") as! String
                                postObj.postThumbnailUrlString = post.valueForKeyPath("featured_image_thumbnail_url") as! String
                                
                                arrayOfPost.append(postObj)
                            }
                            
                            //Mark - Classify Posts Based on Category Type
                            
                            if categoryCode == 1 {
                                self.post1 = arrayOfPost
                                self.thirdCategoryCollectionView.reloadData()
                            }
                            if categoryCode == 2 {
                                self.post2 = arrayOfPost
                                self.thirdCategoryCollectionView.reloadData()
                            }
                            
                        }
                    })
                }
            }
        }
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
         print("selected 3")
        postDelegate?.selectedPost(self.post2[indexPath.row], index: 2)
    }
}
