//
//  Author.swift
//  MyFirstApp
//
//  Created by Hui Guo on 16/8/21.
//  Copyright © 2016年 Leo. All rights reserved.
//

import Foundation

class Author: NSObject{
    
    var authorName: String = ""
    var authorDescription: String = ""
    var authorAvatarUrlDic = NSDictionary()
    var authorAvatarUrlString: String = ""
}