//
//  DetailTableViewController3.swift
//  MyFirstApp
//
//  Created by Hui Guo on 16/8/22.
//  Copyright © 2016年 Leo. All rights reserved.
//

import UIKit

class DetailTableViewController3: UITableViewController {

    var passPost: Posts = Posts()
    
}
