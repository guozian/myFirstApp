//
//  HomePageTableViewController.swift
//  MyFirstApp
//
//  Created by Hui Guo on 16/8/21.
//  Copyright © 2016年 Leo. All rights reserved.
//

import UIKit

class HomePageTableViewController: UITableViewController, PostDelegate {
    

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 3
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        
        if indexPath.section == 0 {
           
            let cell = tableView.dequeueReusableCellWithIdentifier("TableViewCell1") as! HomePageTableViewCell1
            
            cell.getCategory()
//            cell.scrollToNextCell()
//            cell.startTimer()
            cell.postDelegate = self
            tableView.rowHeight = 260
            cell.tag == 0
            return cell
        }
        
         else if indexPath.section == 1 {
            
            let cell = tableView.dequeueReusableCellWithIdentifier("TableViewCell2") as! HomePageTableViewCell2
            
            cell.getCategory()
            tableView.rowHeight = 140
            
            
            return cell
        }
         else {
            
            let cell = tableView.dequeueReusableCellWithIdentifier("TableViewCell3") as! HomePageTableViewCell3
            
            cell.getCategory()
            tableView.rowHeight = 470
            return cell
        }
        
    }


    func selectedPost(post: Posts, index: Int) {
        //You will get your post object here, do what you want now
        if index == 0 {
            self.performSegueWithIdentifier("goToDetail", sender: post)
        }
        else if index == 1 {
            self.performSegueWithIdentifier("goToDetail2", sender: post)
        }
        else {
            self.performSegueWithIdentifier("goToDetail3", sender: post)
        }

        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
       if segue.identifier == "goToDetail"{
        
            let post = sender as! Posts
            
            let postDetailPage = segue.destinationViewController as? DetailTableViewController
            postDetailPage!.passPost = post
        }
    if segue.identifier == "goToDetail2" {
        
        let post = sender as! Posts
        
        let postDetailPage = segue.destinationViewController as? DetailTableViewController2
        postDetailPage!.passPost = post
        
        }
        
        if segue.identifier == "goToDetail3" {
            
            let post = sender as! Posts
            
            let postDetailPage = segue.destinationViewController as? DetailTableViewController3
            postDetailPage!.passPost = post
        }
        
    }
}













