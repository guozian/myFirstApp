//
//  Category.swift
//  MyFirstApp
//
//  Created by Hui Guo on 16/8/21.
//  Copyright © 2016年 Leo. All rights reserved.
//

import Foundation
import UIKit

class Category: NSObject {
    
    var theCategoryArray = NSArray()
    var theDictionary = NSDictionary()
    var postCategoryListUrl: String = ""
    var postCategoryCode = NSNumber()
    var postCategoryName: String = ""
    
}