//
//  DetailTableViewController2.swift
//  MyFirstApp
//
//  Created by Hui Guo on 16/8/22.
//  Copyright © 2016年 Leo. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage

class DetailTableViewController2: UITableViewController {

    var passPost: Posts = Posts()
    
    
    
}
